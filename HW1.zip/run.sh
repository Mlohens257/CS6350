#! /bin/bash

echo "running python code..."
python main.py
